`timescale 1ns / 1ps

module top_gates2(
    input [1:0] sw,
    output [7:0] led
    );
    
    gates2 C1(
        .a(sw[0]),
        .b(sw[1]),
        .z(led)
    );
endmodule
