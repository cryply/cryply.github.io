`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/12/2015 10:55:03 PM
// Design Name: 
// Module Name: gates2
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module gates2(
    input a,
    input b,
    output [3:0] z
    );

wire a,b;
reg [3:0]z;

always @(a or b) 
begin
    z[0] = a & b;
    z[1] = a | b;
    z[2] = a ^ b;
    z[3] = !(a | b);
end    
endmodule
